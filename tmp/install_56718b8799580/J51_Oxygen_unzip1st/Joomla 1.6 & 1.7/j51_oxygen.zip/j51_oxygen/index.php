<?php
defined('_JEXEC') or die;
// JPlugin::loadLanguage( 'tpl_SG1' );
JHTML::_('behavior.mootools');
define( 'Jmasterframework', dirname(__FILE__) );
require( Jmasterframework.DS."config.php");
$path = $this->baseurl.'/templates/'.$this->template;
$app = JFactory::getApplication();
$app->getCfg('sitename');
$siteName = $this->params->get('siteName');
$sidecol_width = $this->params->get('sidecol_width');
$col_pos = $this->params->get('col_pos');
$bg_state = $this->params->get('bg_state');
$templateparams	= $app->getTemplate(true)->params;
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $this->language; ?>" lang="<?php echo $this->language; ?>" >
<head>
<jdoc:include type="head" />
<link rel="stylesheet" href="templates/system/css/system.css" type="text/css" />
<link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template?>/css/template.css" type="text/css" />
<link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template?>/css/sidepanel.css" type="text/css" />
<link rel="stylesheet" href="templates/<?php echo $this->template ?>/css/<?php echo $this->params->get('colorStyle'); ?>.css" type="text/css" />

<script type="text/javascript" src="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/js/UvumiDropdown.js"></script>
<script type="text/javascript">
	var menu = new UvumiDropdown('moomenu');
</script>

<style type="text/css">
#sidecol {width: <?php echo ($sidecol_width); ?>px }
#content80 {width: <?php echo 865 - $sidecol_width ?>px }
		
<?php if($this->params->get('col_pos') == 'col_l') : ?>
#content80 {float:right; padding-right:25px; padding-left:0px;}
#sidecol {float:left; padding:0 0px 0 25px;}
<?php else : ?>
#content80 {float:left; padding-right:0px; padding-left:25px;}
#sidecol {float:right; padding:0 25px 0 0px;}
<?php endif; ?>

<?php if($this->params->get('bg_state') == 'bg_scroll') : ?>
#body_bg {background-attachment: scroll !important;}
<?php else : ?>
#body_bg {background-attachment: fixed !important;}
<?php endif; ?>
</style>

</head>

<!--[if IE 7]>
<link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template?>/css/ie7.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">
window.addEvent('domready', function(){
   var menu_li_els = document.getElementById('hornav').firstChild.childNodes;
   for(var i=0;i<menu_li_els.length; i++) {
      menu_li_els[i].insertBefore(document.createElement('div'), menu_li_els[i].lastChild);
   }
});
</script>
<![endif]-->

<!--[if IE 6]>
<script type="text/javascript" src="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/js/fix-png-ie6.js"></script>
<script type="text/javascript" >
	DD_belatedPNG.fix('.png, img.png, #header, #base_bg');
</script>
<script type="text/javascript">
window.addEvent('domready', function(){
   var menu_li_els = document.getElementById('hornav').firstChild.childNodes;
   for(var i=0;i<menu_li_els.length; i++) {
      menu_li_els[i].insertBefore(document.createElement('div'), menu_li_els[i].lastChild);
   }
});
</script>
<link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template?>/css/ie6.css" rel="stylesheet" type="text/css" />
<script src="<?php echo $this->baseurl ?>/templates/<?php echo $this->template?>/js/ie6/warning.js"></script><script>window.onload=function(){e("<?php echo $this->baseurl ?>/templates/<?php echo $this->template?>/js/ie6/")}</script>
<![endif]-->

<?php
if($this->countModules('sidecolumn') == 0) $contentwidth = "100";
if($this->countModules('sidecolumn') >= 1) $contentwidth = "80";
?> 

<body> 
		
<div id="body_bg">
<div id="wrapper">

	<div id="header"> 
		<div class="logo_container">		
			<?php if($this->params->get('logoType') == 'image') : ?>
			<h1 class="logo"> <a href="index.php" title="<?php echo $siteName; ?>"><span>
			  <?php echo $siteName; ?>
			  </span></a> </h1>
				<?php else : ?>

			<h1 class="logo-text"> <a href="index.php" title="<?php echo $this->params->get('siteName'); ?>"><span>
			  <?php echo $this->params->get('logoText'); ?>
			  </span></a> </h1>
				<p class="site-slogan"><?php echo $this->params->get('sloganText'); ?></p>
			<?php endif; ?>
		</div> 
	</div>
	
	<div id="top">	
			<div id="hornav">
				<jdoc:include type="modules" name="hornav" />
			</div>	
	</div>

	<div id="content_wrapper">
		<div class="content_wrapper">
			<?php if ($this->countModules( 'showcase' )) : ?>
				<div id="showcase">
						<jdoc:include type="modules" name="showcase" style="none" />
				</div>
					
			<?php endif; ?>
	
		<?php if ($this->countModules( 'breadcrumb' )) : ?>
		<div id="breadcrumbs">
				<jdoc:include type="module" name="breadcrumbs" style="none" />
		</div>
		<?php endif; ?>
	
			<!-- Modules USER 7,8,9,10,11,12-->
				<?php if ($this->countModules('user7') || $this->countModules('user8') || $this->countModules('user9') || $this->countModules('user10') || $this->countModules('user11') || $this->countModules('user12')) { ?>
					<div class="spacer">&nbsp;</div>
					<div class="wrapper_moduleblock2">
						<div class="wrapper_mb2_padding">
						<?php if ($this->countModules('user7')) { ?>
						<div class="moduleblock2" style="width:<?php echo $modules_789_width ?>;"><div class="module_padding"><jdoc:include type="modules" name="user7"  style="j51_module"/></div></div><?php } ?>
						<?php if ($this->countModules('user8')) { ?>
						<div class="moduleblock2" style="width:<?php echo $modules_789_width ?>;"><div class="module_padding"><jdoc:include type="modules" name="user8"  style="j51_module"/></div></div><?php } ?>
						<?php if ($this->countModules('user9')) { ?>
						<div class="moduleblock2" style="width:<?php echo $modules_789_width ?>;"><div class="module_padding"><jdoc:include type="modules" name="user9"  style="j51_module"/></div></div><?php } ?>
						<?php if ($this->countModules('user10')) { ?>
						<div class="moduleblock2" style="width:<?php echo $modules_789_width ?>;"><div class="module_padding"><jdoc:include type="modules" name="user10"  style="j51_module"/></div></div><?php } ?>
						<?php if ($this->countModules('user11')) { ?>
						<div class="moduleblock2" style="width:<?php echo $modules_789_width ?>;"><div class="module_padding"><jdoc:include type="modules" name="user11"  style="j51_module"/></div></div><?php } ?>
						<?php if ($this->countModules('user12')) { ?>
						<div class="moduleblock2" style="width:<?php echo $modules_789_width ?>;"><div class="module_padding"><jdoc:include type="modules" name="user12"  style="j51_module"/></div></div><?php } ?>
					</div>
					</div>
				<?php } ?>
			<!--End Modules USER 7,8,9,10,11,12-->
			

	
		<?php if ($this->countModules( 'sidecolumn' )) : ?>
		<div id="sidecol">
			<div class="sidecol_block">
			  <jdoc:include type="modules" name="sidecolumn" style="j51_module" />
			</div>
		</div>
		<?php endif; ?>
	
		  <div id="content<?php echo $contentwidth; ?>">
	
		<div class="inside">
	
			   <!--Modules USER 1,2,3-->
			<?php if ($this->countModules('user1') || $this->countModules('user2') || $this->countModules('user3')) { ?>
				<div class="wrapper_moduleblock1">
				  <?php if ($this->countModules('user1')) { ?>
							<div class="moduleblock1" style="width:<?php echo $modules_123_width ?>;"><div class="module_padding"><jdoc:include type="modules" name="user1"  style="j51_module"/></div></div><?php } ?>
							<?php if ($this->countModules('user2')) { ?>
							<div class="moduleblock1" style="width:<?php echo $modules_123_width ?>;"><div class="module_padding"><jdoc:include type="modules" name="user2"  style="j51_module"/></div></div><?php } ?>
							<?php if ($this->countModules('user3')) { ?>
							<div class="moduleblock1" style="width:<?php echo $modules_123_width ?>;"><div class="module_padding"><jdoc:include type="modules" name="user3"  style="j51_module"/></div></div><?php } ?>
				
			</div>
		
				<?php } ?>
				<!--End Modules USER 1,2,3-->
<div class="spacer">&nbsp;</div>
			<div class="maincontent">
				<div class="message">
					<?php if ($this->getBuffer( 'message' )) : ?>
					<jdoc:include type="message" />
					<?php endif; ?>
				</div>
			  <jdoc:include type="component" /> 
			  </div> 
			<div class="both"><!-- --></div>
			<div class="spacer">&nbsp;</div>
			<!-- Modules USER 4,5,6-->
				<?php if ($this->countModules('user4') || $this->countModules('user5') || $this->countModules('user6')) { ?>
					<div class="wrapper_moduleblock1">
						<?php if ($this->countModules('user4')) { ?>
						<div class="moduleblock1" style="width:<?php echo $modules_456_width ?>;"><div class="module_padding"><jdoc:include type="modules" name="user4"  style="j51_module"/></div></div><?php } ?>
						<?php if ($this->countModules('user5')) { ?>
						<div class="moduleblock1" style="width:<?php echo $modules_456_width ?>;"><div class="module_padding"><jdoc:include type="modules" name="user5"  style="j51_module"/></div></div><?php } ?>
						<?php if ($this->countModules('user6')) { ?>
						<div class="moduleblock1" style="width:<?php echo $modules_456_width ?>;"><div class="module_padding"><jdoc:include type="modules" name="user6"  style="j51_module"/></div></div><?php } ?>
					</div>
				<?php } ?>
			<!--End Modules USER 4,5,6-->
	
		</div>
		</div>
		<div class="both"><!-- --></div>
			<!-- Modules USER 7,8,9,10,11,12-->
				<?php if ($this->countModules('user13') || $this->countModules('user14') || $this->countModules('user15') || $this->countModules('user16') || $this->countModules('user17') || $this->countModules('user18')) { ?>
					<div class="wrapper_moduleblock3">
						<div class="wrapper_mb3_padding">
						<?php if ($this->countModules('user13')) { ?>
						<div class="moduleblock3" style="width:<?php echo $modules_1314_width ?>;"><div class="module_padding"><jdoc:include type="modules" name="user13"  style="j51_module"/></div></div><?php } ?>
						<?php if ($this->countModules('user14')) { ?>
						<div class="moduleblock3" style="width:<?php echo $modules_1314_width ?>;"><div class="module_padding"><jdoc:include type="modules" name="user14"  style="j51_module"/></div></div><?php } ?>
						<?php if ($this->countModules('user15')) { ?>
						<div class="moduleblock3" style="width:<?php echo $modules_1314_width ?>;"><div class="module_padding"><jdoc:include type="modules" name="user15"  style="j51_module"/></div></div><?php } ?>
						<?php if ($this->countModules('user16')) { ?>
						<div class="moduleblock3" style="width:<?php echo $modules_1314_width ?>;"><div class="module_padding"><jdoc:include type="modules" name="user16"  style="j51_module"/></div></div><?php } ?>
						<?php if ($this->countModules('user17')) { ?>
						<div class="moduleblock3" style="width:<?php echo $modules_1314_width ?>;"><div class="module_padding"><jdoc:include type="modules" name="user17"  style="j51_module"/></div></div><?php } ?>
						<?php if ($this->countModules('user18')) { ?>
						<div class="moduleblock3" style="width:<?php echo $modules_1314_width ?>;"><div class="module_padding"><jdoc:include type="modules" name="user18"  style="j51_module"/></div></div><?php } ?>
					</div>
					</div>
				<?php } ?>
			<!--End Modules USER 13,14,15,16,17,18-->

			<div id="base">&nbsp;</div>
		<div id="base">&nbsp;</div>
	
		</div>
	</div>
<div id="base_bg">&nbsp;</div>
</div>
<div id="base_wrapper">

			<div id="base">&nbsp;</div>
<?php if ($this->countModules( 'banner' )) : ?>
		<div id="banner">
			<div class="inside">
			  <jdoc:include type="modules" name="banner" style="none" />
			</div>
		</div>
<?php endif; ?>
</div>

<?php if ($this->countModules( 'footer' )) : ?>
	  <div id="footer">
			<div class="inside">
			  <jdoc:include type="modules" name="footer" style="none" />
			</div>
	  </div>	
<?php endif; ?>


<!-- Footer Copyright - Do Not Remove -->
<?php
/**
 * This Joomla template is released under the Creative Commons Attribution 3.0 license.. 
 * This means that it can be used for private and commercial purposes, edited freely or 
 * redistributed as long as you keep the link back to Joomla51.
 * 
 * If you would like to remove this link, please purchase a license. The license price 
 * for this template is �10.00/$14.00 made payable via Paypal to info@joomla51.com
 * 
 * Please state the intended URL of your website in the comment section of your payment.
 * 
 * The license may be used for a single website only.
 *
 */
?>
<center><p><a href="http://www.joomla51.com"><strong>Joomla Templates</strong></a> by Joomla51.com</p></center>
<!--end of Footer Copyright -->


<jdoc:include type="modules" name="debug" />
</body> 
</html>